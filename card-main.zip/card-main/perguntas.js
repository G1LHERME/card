criaCartao(
    'Geografia ', 
    'Qual a capital do brasil?',
    'Brasília'
)

criaCartao(
    'Geografia ',
    'Qual a capital do paraná? ',
    'Curitiba '
)

criaCartao(
    'Geografia ',
    'Qual a capital da frança?',
    'Paris '
)

criaCartao(
    'Geografia ',
    'Qual a capital da alemanha?',
    'Berlim'
)

criaCartao(
    'Geografia ',
    'Qual a capital da itália?',
    'Roma '
)

criaCartao(
    'Geografia ',
    'Qual a capital da espanha?',
    'Madrid '
)

criaCartao(
    'Geografia ',
    'Qual a capital de portugal? ',
    'Lisboa '
)

criaCartao(
    'Geografia ',
    'Qual a capital da polõnia?',
    'Varsóvia '
)

criaCartao(
    'Geografia ',
    'Qual a capital da ucrãnia?',
    'Kiev'
)

criaCartao(
    'Geografia ',
    'Qual a capital da rússia?',
    'Moscou'
)
